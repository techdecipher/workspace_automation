import argparse
from pathlib import Path
from datetime import datetime

from docx import Document
from docx.shared import Pt, Inches


FIELDS = [
    "Title",
    "Status",
    "Current Activity",
    "What's Being Done",
    "Dependency",
    "Reason",
]


def read_raw_log(file_path: Path) -> str:
    if not file_path.exists():
        raise FileNotFoundError(f"Raw log file not found: {file_path}")

    return file_path.read_text(encoding="utf-8")


def parse_manager_update(content: str) -> dict:
    data = {}

    inside_manager = False
    current_group = None
    current_ticket = None

    for line in content.splitlines():
        stripped = line.strip()

        if stripped == "# Manager Personal Update":
            inside_manager = True
            continue

        if not inside_manager:
            continue

        # Stop if another top-level section starts
        if stripped.startswith("# ") and stripped != "# Manager Personal Update":
            break

        if stripped.startswith("## "):
            current_group = stripped.replace("## ", "").strip()
            data[current_group] = []
            current_ticket = None
            continue

        if stripped.startswith("### "):
            ticket_heading = stripped.replace("### ", "").strip()
            current_ticket = {
                "Heading": ticket_heading,
                "Title": "",
                "Status": "",
                "Current Activity": "",
                "What's Being Done": "",
                "Dependency": "",
                "Reason": "",
                "Environment": [],
            }

            if current_group:
                data[current_group].append(current_ticket)

            continue

        if not current_ticket or not stripped:
            continue

        for field in FIELDS:
            prefix = f"{field}:"
            if stripped.startswith(prefix):
                current_ticket[field] = stripped.replace(prefix, "").strip()
                break

        if stripped.startswith("- "):
            current_ticket["Environment"].append(stripped.replace("- ", "").strip())

    return data


def set_normal_style(document: Document):
    styles = document.styles
    styles["Normal"].font.name = "Aptos"
    styles["Normal"].font.size = Pt(11)


def add_group_heading(document: Document, text: str):
    paragraph = document.add_paragraph()
    paragraph.paragraph_format.space_before = Pt(10)
    paragraph.paragraph_format.space_after = Pt(8)

    run = paragraph.add_run(text)
    run.bold = True
    run.font.name = "Aptos"
    run.font.size = Pt(11)


def add_ticket_title(document: Document, number: int, title: str):
    paragraph = document.add_paragraph()
    paragraph.paragraph_format.space_before = Pt(4)
    paragraph.paragraph_format.space_after = Pt(8)

    run = paragraph.add_run(f"{number}. {title}")
    run.bold = True
    run.font.name = "Aptos"
    run.font.size = Pt(11)


def add_bullet_field(document: Document, label: str, value: str):
    paragraph = document.add_paragraph(style="List Bullet")
    paragraph.paragraph_format.left_indent = Inches(0.45)
    paragraph.paragraph_format.space_before = Pt(2)
    paragraph.paragraph_format.space_after = Pt(4)

    label_run = paragraph.add_run(f"{label}: ")
    label_run.bold = True
    label_run.font.name = "Aptos"
    label_run.font.size = Pt(11)

    value_run = paragraph.add_run(value or "")
    value_run.font.name = "Aptos"
    value_run.font.size = Pt(11)


def add_environment_section(document: Document, environments: list):
    paragraph = document.add_paragraph(style="List Bullet")
    paragraph.paragraph_format.left_indent = Inches(0.45)
    paragraph.paragraph_format.space_before = Pt(2)
    paragraph.paragraph_format.space_after = Pt(4)

    label_run = paragraph.add_run("Environment:")
    label_run.bold = True
    label_run.font.name = "Aptos"
    label_run.font.size = Pt(11)

    if not environments:
        env_paragraph = document.add_paragraph(style="List Bullet 2")
        env_paragraph.paragraph_format.left_indent = Inches(0.75)
        env_run = env_paragraph.add_run("Not specified")
        env_run.font.name = "Aptos"
        env_run.font.size = Pt(11)
        return

    for env in environments:
        env_paragraph = document.add_paragraph(style="List Bullet 2")
        env_paragraph.paragraph_format.left_indent = Inches(0.75)
        env_paragraph.paragraph_format.space_before = Pt(1)
        env_paragraph.paragraph_format.space_after = Pt(2)

        env_run = env_paragraph.add_run(env)
        env_run.font.name = "Aptos"
        env_run.font.size = Pt(11)


def generate_manager_update_docx(data: dict, output_path: Path):
    document = Document()

    section = document.sections[0]
    section.top_margin = Inches(0.7)
    section.bottom_margin = Inches(0.7)
    section.left_margin = Inches(0.9)
    section.right_margin = Inches(0.9)

    set_normal_style(document)

    if not data:
        document.add_paragraph("No manager personal update found in the markdown file.")

    for group_name, tickets in data.items():
        add_group_heading(document, group_name)

        if not tickets:
            document.add_paragraph("No in-progress updates.")
            continue

        for index, ticket in enumerate(tickets, start=1):
            add_ticket_title(document, index, ticket.get("Heading") or ticket.get("Title") or "Ticket Title")

            add_bullet_field(document, "Title", ticket.get("Title", ""))
            add_bullet_field(document, "Status", ticket.get("Status", "In Progress"))
            add_bullet_field(document, "Current Activity", ticket.get("Current Activity", ""))
            add_bullet_field(document, "What’s Being Done", ticket.get("What's Being Done", ""))
            add_bullet_field(document, "Dependency", ticket.get("Dependency", ""))
            add_bullet_field(document, "Reason", ticket.get("Reason", ""))
            add_environment_section(document, ticket.get("Environment", []))

    output_path.parent.mkdir(parents=True, exist_ok=True)
    document.save(output_path)


def main():
    parser = argparse.ArgumentParser(
        description="Generate manager personal update Word document from markdown file."
    )

    parser.add_argument(
        "--date",
        required=False,
        default=datetime.today().strftime("%Y-%m-%d"),
        help="Date of the raw log file in YYYY-MM-DD format. Example: 2026-06-12. If not provided, today's date will be used.",
    )

    args = parser.parse_args()

    base_dir = Path(__file__).parent
    input_file = base_dir / "raw_logs" / f"{args.date}.md"

    output_dir = base_dir / "output"
    output_dir.mkdir(parents=True, exist_ok=True)

    output_file = output_dir / f"Manager_Update_{args.date}.docx"

    if output_file.exists():
        timestamp = datetime.now().strftime("%H%M%S")
        output_file = output_dir / f"Manager_Update_{args.date}_{timestamp}.docx"

    content = read_raw_log(input_file)
    parsed_data = parse_manager_update(content)
    generate_manager_update_docx(parsed_data, output_file)

    print(f"Manager update generated successfully: {output_file}")


if __name__ == "__main__":
    main()