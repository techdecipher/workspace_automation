import argparse
from pathlib import Path
from datetime import datetime

from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH


def read_raw_log(file_path: Path) -> str:
    if not file_path.exists():
        raise FileNotFoundError(f"Raw log file not found: {file_path}")

    return file_path.read_text(encoding="utf-8")


def parse_weekly_sections(content: str) -> dict:
    data = {
        "Weekly Greeting": "",
        "Weekly In Progress": [],
        "Weekly Completed": [],
    }

    inside_weekly = False
    current_section = None

    for line in content.splitlines():
        stripped = line.strip()

        if stripped == "# Weekly Update":
            inside_weekly = True
            current_section = None
            continue

        if not inside_weekly:
            continue

        if stripped.startswith("# ") and stripped != "# Weekly Update":
            break

        if stripped.startswith("## "):
            current_section = stripped.replace("## ", "").strip()
            continue

        if not stripped:
            continue

        if current_section == "Weekly Greeting":
            if data["Weekly Greeting"]:
                data["Weekly Greeting"] += " " + stripped
            else:
                data["Weekly Greeting"] = stripped

        elif current_section in ["Weekly In Progress", "Weekly Completed"]:
            if stripped.startswith("- "):
                data[current_section].append(stripped.replace("- ", "").strip())

    return data


def set_normal_style(document: Document):
    styles = document.styles
    styles["Normal"].font.name = "Calibri"
    styles["Normal"].font.size = Pt(11)


def add_bold_heading(document: Document, text: str):
    paragraph = document.add_paragraph()
    run = paragraph.add_run(text)
    run.bold = True
    run.font.size = Pt(12)
    paragraph.space_before = Pt(10)
    paragraph.space_after = Pt(6)


def add_bullet(document: Document, text: str, bold_prefix=False):
    paragraph = document.add_paragraph(style="List Bullet")
    paragraph.paragraph_format.left_indent = Inches(0.35)

    if bold_prefix and ":" in text:
        prefix, rest = text.split(":", 1)

        run1 = paragraph.add_run(prefix + ":")
        run1.bold = True
        run1.font.size = Pt(11)

        run2 = paragraph.add_run(rest)
        run2.font.size = Pt(11)
    else:
        run = paragraph.add_run(text)
        run.font.size = Pt(11)


def generate_weekly_update_docx(data: dict, output_path: Path):
    document = Document()

    section = document.sections[0]
    section.top_margin = Inches(0.8)
    section.bottom_margin = Inches(0.8)
    section.left_margin = Inches(0.9)
    section.right_margin = Inches(0.9)

    set_normal_style(document)

    document.add_paragraph("Hi")

    greeting = data.get("Weekly Greeting") or "Pereira, Macson, Please find the below weekly updates."
    document.add_paragraph(greeting)

    add_bold_heading(document, "In Progress")

    if data["Weekly In Progress"]:
        for item in data["Weekly In Progress"]:
            add_bullet(document, item, bold_prefix=True)
    else:
        add_bullet(document, "No in-progress update.")

    add_bold_heading(document, "Completed")

    if data["Weekly Completed"]:
        for item in data["Weekly Completed"]:
            add_bullet(document, item)
    else:
        add_bullet(document, "No completed update.")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    document.save(output_path)


def main():
    parser = argparse.ArgumentParser(
        description="Generate weekly update Word document from markdown file."
    )

    parser.add_argument(
        "--date",
        required=False,
        default=datetime.today().strftime("%Y-%m-%d"),
        help="Date of the raw log file in YYYY-MM-DD format. Example: 2026-06-12. If not provided, today's date will be used.",
    )

    args = parser.parse_args()

    base_dir = Path(__file__).parent
    input_file = base_dir / "raw_logs" / f"{args.date}.md"

    output_dir = base_dir / "output"
    output_dir.mkdir(parents=True, exist_ok=True)

    output_file = output_dir / f"Weekly_Update_{args.date}.docx"

    if output_file.exists():
        timestamp = datetime.now().strftime("%H%M%S")
        output_file = output_dir / f"Weekly_Update_{args.date}_{timestamp}.docx"

    content = read_raw_log(input_file)
    parsed_data = parse_weekly_sections(content)
    generate_weekly_update_docx(parsed_data, output_file)

    print(f"Weekly update generated successfully: {output_file}")


if __name__ == "__main__":
    main()