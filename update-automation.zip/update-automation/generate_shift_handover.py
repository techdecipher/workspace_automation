import argparse
from pathlib import Path
from datetime import datetime

from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn


SECTIONS = [
    "Priority Tickets / High-Impact Issues",
    "Other Updates If any",
    "Completed tasks in this shift",
]

COLUMNS = [
    "Ticket ID",
    "Issue Summary",
    "Current Status",
    "ETA",
    "Pending Action / Owner",
    "Next Step",
]


def read_raw_log(file_path: Path) -> str:
    if not file_path.exists():
        raise FileNotFoundError(f"Raw log file not found: {file_path}")

    return file_path.read_text(encoding="utf-8")


def parse_markdown_table(lines):
    rows = []

    for line in lines:
        line = line.strip()

        if not line.startswith("|"):
            continue

        # Skip separator row like |---|---|---|
        cleaned = line.replace("|", "").replace("-", "").replace(" ", "")
        if cleaned == "":
            continue

        cells = [cell.strip() for cell in line.strip("|").split("|")]

        # Skip header row
        if cells == COLUMNS:
            continue

        # Normalize to 6 columns
        while len(cells) < 6:
            cells.append("")

        rows.append(cells[:6])

    return rows


def parse_raw_markdown(content: str) -> dict:
    data = {
        "Title": "",
        "Priority Tickets / High-Impact Issues": [],
        "Other Updates If any": [],
        "Completed tasks in this shift": [],
    }

    current_section = None
    section_lines = []

    def save_current_section():
        if current_section:
            data[current_section] = parse_markdown_table(section_lines)

    for line in content.splitlines():
        stripped = line.strip()

        if stripped.startswith("# Title:"):
            data["Title"] = stripped.replace("# Title:", "").strip()
            continue

        if stripped.startswith("## "):
            save_current_section()
            current_section = stripped.replace("## ", "").strip()
            section_lines = []
            continue

        if current_section:
            section_lines.append(line)

    save_current_section()

    if not data["Title"]:
        today = datetime.today().strftime("%d-%B-%Y")
        data["Title"] = f"Afternoon Shift Handover [{today}]"

    return data


def set_cell_text(cell, text, bold=False, font_size=8.5, align="left"):
    cell.text = ""

    paragraph = cell.paragraphs[0]

    if align == "center":
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == "right":
        paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    else:
        paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT

    run = paragraph.add_run(text)
    run.bold = bold
    run.font.name = "Calibri"
    run.font.size = Pt(font_size)

    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def set_cell_border(cell):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()

    borders = tc_pr.first_child_found_in("w:tcBorders")
    if borders is None:
        borders = OxmlElement("w:tcBorders")
        tc_pr.append(borders)

    for edge in ("top", "left", "bottom", "right"):
        tag = f"w:{edge}"
        element = borders.find(qn(tag))

        if element is None:
            element = OxmlElement(tag)
            borders.append(element)

        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), "6")
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), "808080")


def set_cell_width(cell, width_twips):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_w = tc_pr.first_child_found_in("w:tcW")

    if tc_w is None:
        tc_w = OxmlElement("w:tcW")
        tc_pr.append(tc_w)

    tc_w.set(qn("w:w"), str(width_twips))
    tc_w.set(qn("w:type"), "dxa")


def set_row_height(row, height_twips):
    tr_pr = row._tr.get_or_add_trPr()
    tr_height = OxmlElement("w:trHeight")
    tr_height.set(qn("w:val"), str(height_twips))
    tr_height.set(qn("w:hRule"), "atLeast")
    tr_pr.append(tr_height)


def format_table_grid(table):
    # Column width ratio based on your screenshot
    widths = [1250, 1700, 4300, 600, 1300, 900]

    for row in table.rows:
        for idx, cell in enumerate(row.cells):
            set_cell_border(cell)
            set_cell_width(cell, widths[idx])


def add_section_header_row(table, text):
    row = table.add_row()
    merged_cell = row.cells[0]

    for i in range(1, 6):
        merged_cell = merged_cell.merge(row.cells[i])

    set_cell_text(row.cells[0], text, bold=True, font_size=8.5)
    set_row_height(row, 320)


def add_empty_top_rows(table):
    # These rows match the empty placeholder rows in your team template.
    # Keep text as "empty" only if you want it visible.
    # Change values to "" if you want those cells blank.
    row = table.add_row()
    values = ["", "", "", "", "", ""]

    for i, value in enumerate(values):
        set_cell_text(row.cells[i], value, bold=True, font_size=8.5)

    set_row_height(row, 720)

    row = table.add_row()
    values = [
        "Priority\nTickets /\nHigh-Impact Issues",
        "",
        "",
        "",
        "",
        "",
    ]

    for i, value in enumerate(values):
        set_cell_text(row.cells[i], value, bold=True, font_size=8.5)

    set_row_height(row, 1200)


def add_column_header_row(table):
    row = table.add_row()

    headers = [
        "Ticket ID",
        "Issue Summary",
        "Current Status",
        "ETA",
        "Pending\nAction /\nOwner",
        "Next\nStep",
    ]

    for i, header in enumerate(headers):
        set_cell_text(row.cells[i], header, bold=True, font_size=8.5)

    set_row_height(row, 650)


def add_data_rows(table, rows, minimum_rows=1):
    final_rows = rows.copy()

    while len(final_rows) < minimum_rows:
        final_rows.append(["", "", "", "", "", ""])

    for row_data in final_rows:
        row = table.add_row()

        for i, value in enumerate(row_data):
            set_cell_text(row.cells[i], value, bold=False, font_size=8.5)

        set_row_height(row, 1300)


def add_blank_separator_row(table):
    row = table.add_row()

    for cell in row.cells:
        set_cell_text(cell, "", font_size=8.5)

    set_row_height(row, 250)


def generate_shift_handover_docx(data: dict, output_path: Path):
    document = Document()

    section = document.sections[0]
    section.top_margin = Inches(0.35)
    section.bottom_margin = Inches(0.35)
    section.left_margin = Inches(0.35)
    section.right_margin = Inches(0.35)

    styles = document.styles
    styles["Normal"].font.name = "Calibri"
    styles["Normal"].font.size = Pt(8.5)

    table = document.add_table(rows=0, cols=6)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False

    # Title row
    title_row = table.add_row()
    title_cell = title_row.cells[0]

    for i in range(1, 6):
        title_cell = title_cell.merge(title_row.cells[i])

    set_cell_text(
        title_row.cells[0],
        f"Title : {data['Title']}",
        bold=True,
        font_size=9.5,
    )
    set_row_height(title_row, 350)

    # Empty placeholder rows
    add_empty_top_rows(table)

    # Main priority ticket section
    add_column_header_row(table)
    add_data_rows(
        table,
        data["Priority Tickets / High-Impact Issues"],
        minimum_rows=1,
    )

    # Blank separator row
    add_blank_separator_row(table)

    # Other Updates section
    add_section_header_row(table, "Other Updates If any:")
    add_data_rows(
        table,
        data["Other Updates If any"],
        minimum_rows=1,
    )

    # Completed section
    add_section_header_row(table, "Completed tasks in this shift:")
    add_data_rows(
        table,
        data["Completed tasks in this shift"],
        minimum_rows=1,
    )

    format_table_grid(table)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    document.save(output_path)


def main():
    parser = argparse.ArgumentParser(
        description="Generate team-style shift handover Word document from markdown file."
    )

    parser.add_argument(
        "--date",
        default=datetime.today().strftime("%Y-%m-%d"),
        help="Date of the raw log file in YYYY-MM-DD format. Example: 2026-06-12. If not provided, today's date will be used.",
    )

    args = parser.parse_args()

    base_dir = Path(__file__).parent
    input_file = base_dir / "raw_logs" / f"{args.date}.md"

    output_dir = base_dir / "output"
    output_dir.mkdir(parents=True, exist_ok=True)

    output_file = output_dir / f"Shift_Handover_{args.date}.docx"

    # If same output file already exists, create timestamped file to avoid permission error
    if output_file.exists():
        timestamp = datetime.now().strftime("%H%M%S")
        output_file = output_dir / f"Shift_Handover_{args.date}_{timestamp}.docx"

    content = read_raw_log(input_file)
    parsed_data = parse_raw_markdown(content)
    generate_shift_handover_docx(parsed_data, output_file)

    print(f"Shift handover generated successfully: {output_file}")


if __name__ == "__main__":
    main()